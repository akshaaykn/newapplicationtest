import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-report-setting-dialog',
  templateUrl: './report-setting-dialog.component.html',
  styleUrls: ['./report-setting-dialog.component.scss']
})
export class ReportSettingDialogComponent implements OnInit {
  public settingForm: FormGroup;
  constructor(public dialogRef: MatDialogRef<ReportSettingDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _formBuilder: FormBuilder) { 
      this.settingForm = this._formBuilder.group({
        reportName: '',
        reportDescription: '',
        p1: false,
        p2: false,
        p3: false,
        p4: false,
        p5: false,
        p6: false,
        p7: false,
        p8: false,
      });
    }

  ngOnInit(): void {
  }

  public closeDialog() {
    this.dialogRef.close();

  }
  saveReport(){
    console.log(this.settingForm.value)
  }

}
