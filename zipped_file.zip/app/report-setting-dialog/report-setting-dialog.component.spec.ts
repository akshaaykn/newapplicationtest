import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportSettingDialogComponent } from './report-setting-dialog.component';

describe('ReportSettingDialogComponent', () => {
  let component: ReportSettingDialogComponent;
  let fixture: ComponentFixture<ReportSettingDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportSettingDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReportSettingDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
