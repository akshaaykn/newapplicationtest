import { Component } from '@angular/core';
const ANNOUNCEMENTS_VIEW_ID = "announcements-view";
const CLASS_VIEW_SHOWN = "view-shown";
const CLASS_VIEW_HIDDEN = "view-hidden";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'app';
  check = false;

  private showAnnouncements() {
    document.getElementById(ANNOUNCEMENTS_VIEW_ID)?.classList.replace(CLASS_VIEW_HIDDEN, CLASS_VIEW_SHOWN);
  }

  private hideAnnouncements() {
    document.getElementById(ANNOUNCEMENTS_VIEW_ID)?.classList.replace(CLASS_VIEW_SHOWN, CLASS_VIEW_HIDDEN);
  }
  private isAnnouncementsOpen() {
    return this.elementHasClass(ANNOUNCEMENTS_VIEW_ID, CLASS_VIEW_SHOWN);
  }


  /**
 * Check if an element with give id has give targetClass
 */
  private elementHasClass(id:any, targetClass:any) {
    const ele = document.getElementById(id);
    if (ele) {
      const classes = ele.classList;
      return classes.contains(targetClass);
    } 
    return false;
  }

  toggleAnnouncementsView() {
    this.check = !this.check;
    // if (this.isAnnouncementsOpen()) {
    //   this.hideAnnouncements();
    // } else {
    //   this.showAnnouncements();
    // }
  }
}
