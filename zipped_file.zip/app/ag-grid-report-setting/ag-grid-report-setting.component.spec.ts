import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgGridReportSettingComponent } from './ag-grid-report-setting.component';

describe('AgGridReportSettingComponent', () => {
  let component: AgGridReportSettingComponent;
  let fixture: ComponentFixture<AgGridReportSettingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgGridReportSettingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgGridReportSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
