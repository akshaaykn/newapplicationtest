import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ReportSettingDialogComponent } from '../report-setting-dialog/report-setting-dialog.component';
@Component({
  selector: 'app-ag-grid-report-setting',
  templateUrl: './ag-grid-report-setting.component.html',
  styleUrls: ['./ag-grid-report-setting.component.scss']
})
export class AgGridReportSettingComponent implements OnInit {
  public pilotTemplate: any = [{
    name: "Report 1",
    description: "Save report description",
    isDefault: false,
    reportDetails: {},
    reportSettings: {}
  },
  {
    name: "Report 2",
    description: "Save report description",
    isDefault: true,
    reportDetails: {},
    reportSettings: {}
  },
  {
    name: "Report 2",
    description: "Save report description",
    isDefault: false,
    reportDetails: {},
    reportSettings: {}
  }]
  public savedTemplates: any = [{
    name: "Summary Report 001",
    description: "Save report description",
    isDefault: false,
    reportDetails: {},
    reportSettings: {}
  },
  {
    name: "Summary Report 002",
    description: "Save report description",
    isDefault: true,
    reportDetails: {},
    reportSettings: {}
  },
  {
    name: "Summary Report 002",
    description: "Save report description",
    isDefault: false,
    reportDetails: {},
    reportSettings: {}
  }
  ]

  public hoverIndex: any;
  public searchTextDefault: string = '';
  public searchTextSaved: string = '';



  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  public hideAnnouncementsView() {

  }
  public enter(index: any) {
    this.hoverIndex = index;
  }

  public leave() {
    this.hoverIndex = null;
  }

  public edit() {
    debugger
  }

  public delete() {
    debugger
  }

  saveReport() {
    let dialogRef:any = this.dialog.open(ReportSettingDialogComponent,{ height: '750px', width: '600px', });
    dialogRef?.afterClosed().subscribe((result: string) => {
      dialogRef = null;
    });
  }
}
